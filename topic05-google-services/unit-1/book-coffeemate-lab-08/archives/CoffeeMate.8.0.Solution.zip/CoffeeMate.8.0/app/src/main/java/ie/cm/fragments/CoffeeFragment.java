package ie.cm.fragments;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.List;

import ie.cm.R;
import ie.cm.activities.Home;
import ie.cm.adapters.CoffeeFilter;
import ie.cm.adapters.CoffeeListAdapter;
import ie.cm.api.CoffeeApi;
import ie.cm.api.VolleyListener;
import ie.cm.models.Coffee;

import static ie.cm.activities.Home.app;

public class CoffeeFragment  extends Fragment implements
        AdapterView.OnItemClickListener,
        View.OnClickListener,
        AbsListView.MultiChoiceModeListener,
        VolleyListener
{
    public Home activity;
    public static CoffeeListAdapter listAdapter;
    public ListView listView;
    public CoffeeFilter coffeeFilter;
    public boolean favourites = false;
    public View v;

    public CoffeeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        Bundle activityInfo = new Bundle(); // Creates a new Bundle object
        activityInfo.putString("coffeeId", (String) view.getTag());

        Fragment fragment = EditFragment.newInstance(activityInfo);
        getActivity().setTitle(R.string.editCoffeeLbl);

        getActivity().getSupportFragmentManager().beginTransaction()
                .replace(R.id.homeFrame, fragment)
                .addToBackStack(null)
                .commit();
    }


    public static CoffeeFragment newInstance() {
        CoffeeFragment fragment = new CoffeeFragment();
        return fragment;
    }

    @Override
    public void onAttach(Context context)
    {
        super.onAttach(context);
        this.activity = (Home) context;
        CoffeeApi.attachListener(this);
        CoffeeApi.attachDialog(activity.loader);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        CoffeeApi.detachListener();
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        CoffeeApi.get("/coffees/" + app.googleToken);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup parent, Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_home, parent, false);
        listView = v.findViewById(R.id.homeList);
        updateView();
        return v;
    }

    public void setListView(View view)
    {
        listView.setAdapter (listAdapter);
        listView.setOnItemClickListener(this);
        listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE_MODAL);
        listView.setMultiChoiceModeListener(this);
        listView.setEmptyView(view.findViewById(R.id.emptyList));
    }

    @Override
    public void onStart()
    {
        super.onStart();
    }

    public void onResume() {
        super.onResume();
        CoffeeApi.attachListener(this);
        updateView();
    }

    public void updateView() {
        listAdapter = new CoffeeListAdapter(activity, this, app.coffeeList);
        coffeeFilter = new CoffeeFilter(app.coffeeList,"all",listAdapter);

        if (favourites) {
            coffeeFilter.setFilter("favourites"); // Set the filter text field from 'all' to 'favourites'
            coffeeFilter.filter(null); // Filter the data, but don't use any prefix
          //  listAdapter.notifyDataSetChanged(); // Update the adapter
        }
        setListView(v);
        setSwipeRefresh(v);

        if(!favourites)
            getActivity().setTitle(R.string.recentlyViewedLbl);
        else
            getActivity().setTitle(R.string.favouritesCoffeeLbl);

        listAdapter.notifyDataSetChanged(); // Update the adapter
    }

    @Override
    public void onClick(View view) {
        if (view.getTag() instanceof Coffee) {
            onCoffeeDelete ((Coffee) view.getTag());
        }
    }

    public void onCoffeeDelete(final Coffee coffee)
    {
        String stringName = coffee.name;
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setMessage("Are you sure you want to Delete the \'Coffee\' " + stringName + "?");
        builder.setCancelable(false);

        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                CoffeeApi.delete("/coffees/" + app.googleToken +
                        "/" + coffee._id,app.googleToken);
            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int id)
            {
                dialog.cancel();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

    /* ************ MultiChoiceModeListener methods (begin) *********** */
    @Override
    public boolean onCreateActionMode(ActionMode actionMode, Menu menu)
    {
        MenuInflater inflater = actionMode.getMenuInflater();
        inflater.inflate(R.menu.delete_list_context, menu);
        return true;
    }

    @Override
    public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
        return false;
    }

    @Override
    public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem)
    {
        switch (menuItem.getItemId())
        {
            case R.id.menu_item_delete_coffee:
                deleteCoffees(actionMode);
                return true;
            default:
                return false;
        }
    }

    public void deleteCoffees(ActionMode actionMode)
    {
        for (int i = listAdapter.getCount() -1 ; i >= 0; i--)
        {
            if (listView.isItemChecked(i))
            {
                CoffeeApi.delete("/coffees/" + app.googleToken
                        + "/" + listAdapter.getItem(i)._id,app.googleToken);

            }
        }
        CoffeeApi.get("/coffees/" + app.googleToken);
        listAdapter.notifyDataSetChanged(); // refresh adapter
        actionMode.finish();
    }


    @Override
    public void onDestroyActionMode(ActionMode actionMode)
    {}

    @Override
    public void onItemCheckedStateChanged(ActionMode actionMode, int i, long l, boolean b) {
    }
    /* ************ MultiChoiceModeListener methods (end) *********** */

    @Override
    public void setList(List list) {
        app.coffeeList = list;
    }

    @Override
    public void setCoffee(Coffee coffee) {
    }

    @Override
    public void updateUI(Fragment fragment) {
        fragment.onResume();
        checkSwipeRefresh(v);
    }

    public void setSwipeRefresh(View v)
    {
        SwipeRefreshLayout swipeRefresh = v.findViewById(R.id.swiperefresh);
        swipeRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                CoffeeApi.get("/coffees/" + app.googleToken);
            }
        });
    }

    public void checkSwipeRefresh(View v)
    {
        SwipeRefreshLayout swipeRefresh = v.findViewById(R.id.swiperefresh);
        if (swipeRefresh.isRefreshing()) swipeRefresh.setRefreshing(false);
    }
}
