package ie.cm.adapters;

import android.content.Context;
import android.widget.Filter;

import java.util.ArrayList;
import java.util.List;

import ie.cm.activities.Base;
import ie.cm.db.DBManager;
import ie.cm.main.CoffeeMateApp;
import ie.cm.models.Coffee;
import io.realm.Case;
import io.realm.OrderedRealmCollection;
import io.realm.RealmResults;

public class CoffeeFilter extends Filter {
	private OrderedRealmCollection<Coffee> 		originalCoffeeList;
	private RealmResults<Coffee> realmCoffeResults;
	private CoffeeListAdapter 	adapter;
	private boolean favourites = false;
	private DBManager dbManager;

	public CoffeeFilter(DBManager dbManager, CoffeeListAdapter adapter) {
		super();
		this.dbManager = dbManager;
		this.originalCoffeeList = dbManager.getAll();
		this.adapter = adapter;
	}

	public void setFilter(String filterText) {
		//favourites = filterText.equals("all") ? false : true;
		favourites = !filterText.equals("all");
	}

	@Override
	protected FilterResults performFiltering(CharSequence prefix) {
		return new FilterResults();
	}

	@Override
	protected void publishResults(CharSequence prefix, FilterResults results) {

		if ((prefix == null || prefix.length() == 0))
				if(!favourites)
					realmCoffeResults = dbManager.getAll();
				else
					realmCoffeResults = dbManager.getFavourites();
		else {
			realmCoffeResults = dbManager.realmDatabase
					.where(Coffee.class)
					.equalTo("favourite", favourites)
					.contains("name", prefix.toString(), Case.INSENSITIVE)
					.or()
					.contains("shop", prefix.toString(), Case.INSENSITIVE)
					.findAll();
		}

		adapter.coffeeList = realmCoffeResults;

		if (adapter.coffeeList.size() > 0)
			adapter.notifyDataSetChanged();
		else {
			adapter.notifyDataSetInvalidated();
			adapter.coffeeList = originalCoffeeList;
		}
	}
}
