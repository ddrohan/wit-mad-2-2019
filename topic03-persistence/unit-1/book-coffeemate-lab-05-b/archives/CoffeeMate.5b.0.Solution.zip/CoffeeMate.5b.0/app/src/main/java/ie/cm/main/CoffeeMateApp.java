package ie.cm.main;

import ie.cm.db.DBManager;
import android.app.Application;
import android.util.Log;

public class CoffeeMateApp extends Application
{
    //public List <Coffee>  coffeeList = new ArrayList<Coffee>();
    public DBManager dbManager;

    @Override
    public void onCreate()
    {
        super.onCreate();
        Log.v("coffeemate", "CoffeeMate App Started");
        dbManager = new DBManager(this);
        dbManager.open();
        Log.v("coffeemate", "Realm Database Created & Opened");
    }

    @Override
    public void onTerminate()
    {
        super.onTerminate();
        Log.v("coffeemate", "Realm Database Closed");
        dbManager.close();
    }
}