package ie.cm.db;

import android.content.Context;
import android.database.SQLException;
import ie.cm.models.Coffee;
import io.realm.Realm;
import io.realm.RealmConfiguration;
import io.realm.RealmResults;

public class DBManager {

    public Realm realmDatabase;

    public DBManager(Context context) {
        Realm.init(context);

        RealmConfiguration config = new RealmConfiguration.Builder()
                .name("coffees.realm")
                .schemaVersion(1)
                .build();

        Realm.setDefaultConfiguration(config);
    }

    public void open() throws SQLException {
        realmDatabase = Realm.getDefaultInstance();
    }

    public void close() {
        realmDatabase.close();
    }

    public void add(Coffee c) {
        realmDatabase.beginTransaction();
        realmDatabase.copyToRealm(c);
        realmDatabase.commitTransaction();
    }

    public void update(Coffee c, String name ,String shop, double price , double rating)
    {
        realmDatabase.beginTransaction();
        c.name = name;
        c.shop = shop;
        c.price = price;
        c.rating = rating;
        realmDatabase.commitTransaction();
    }

    public void setFavourite(Coffee c, boolean value)
    {
        realmDatabase.beginTransaction();
        c.favourite = value;
        realmDatabase.commitTransaction();
    }

    // If we wanted to update individual fields we could
    // do something like this, for example
    public void updateName(String name, String coffeeId)
    {

        Coffee c = realmDatabase.where(Coffee.class)
                .equalTo("coffeeId",coffeeId)
                .findFirst();
        realmDatabase.beginTransaction();
        c.name = name;
        realmDatabase.commitTransaction();
    }

    public void delete(String coffeeId) {
        realmDatabase.beginTransaction();
        realmDatabase.where(Coffee.class)
                .equalTo("coffeeId",coffeeId)
                .findAll()
                .deleteAllFromRealm();
        realmDatabase.commitTransaction();
    }

    public RealmResults<Coffee> getAll() {
        RealmResults<Coffee> result = realmDatabase.where(Coffee.class)
                .findAll();
        return result;
    }

    public RealmResults<Coffee> getFavourites() {
        return realmDatabase.where(Coffee.class)
                .equalTo("favourite",true)
                .findAll();
    }

    public Coffee get(String coffeeId) {
        return realmDatabase.where(Coffee.class)
                .equalTo("coffeeId",coffeeId)
                .findAll()
                .first();
    }

    public void reset() {
        realmDatabase.beginTransaction();
        realmDatabase.where(Coffee.class)
                .findAll()
                .deleteAllFromRealm();
        realmDatabase.commitTransaction();
    }

}
