package ie.cm.api;

import android.support.v4.app.Fragment;

import java.util.List;

public interface VolleyListener {
    void setList(List list);
    void updateUI(Fragment fragment);
}