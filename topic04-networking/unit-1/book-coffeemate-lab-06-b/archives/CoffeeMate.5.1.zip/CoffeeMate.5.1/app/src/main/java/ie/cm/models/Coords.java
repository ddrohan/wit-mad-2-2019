package ie.cm.models;

public class Coords {
    public double latitude;
    public double longitude;
}
