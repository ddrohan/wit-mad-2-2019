package ie.cm.api;

import java.util.List;

import ie.cm.models.Coffee;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface CoffeeService {

    @GET("/coffees/{token}")
    Call<List<Coffee>> getAllCoffees(@Path("token") String token);

    @POST("/coffees/{token}")
    Call<Coffee> createCoffee(@Path("token") String token,
                              @Body Coffee coffee);

    @GET("/coffees/{token}/{id}")
    Call<Coffee> retrieveCoffee(@Path("token") String token,
                                @Path("id") String id);

    @PUT("/coffees/{token}/{id}")
    Call<Coffee> updateCoffee(@Path("token") String token,
                              @Path("id") String id,
                              @Body Coffee coffee);

    @DELETE("/coffees/{token}/{id}")
    Call<List<Coffee>> deleteCoffee(@Path("token") String token,
                              @Path("id") String id);
}

