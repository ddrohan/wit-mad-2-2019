package ie.cm.api;

import java.util.List;

import ie.cm.models.Coffee;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface CoffeeService
{
    @GET("/coffees")
    Call<CoffeeWrapper> getAll();

    @GET("/coffees/{id}")
    Call<CoffeeWrapper> get(@Path("id") String id);

    @DELETE("/coffees/{id}")
    Call<CoffeeWrapper> delete(@Path("id") String id);

    @POST("/coffees")
    Call<CoffeeWrapper> post(@Body Coffee coffee);

    @PUT("/coffees/{id}")
    Call<CoffeeWrapper> put(@Path("id") String id,
                     @Body Coffee coffee);
}
