package ie.cm.api;

import java.util.List;

import ie.cm.models.Coffee;

public class CoffeeWrapper {
    public int status;
    public String message;
    public List<Coffee> data;
}
