package ie.cm.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import ie.cm.R;
import ie.cm.activities.Home;
import ie.cm.api.CoffeeWrapper;
import ie.cm.main.CoffeeMateApp;
import ie.cm.models.Coffee;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddFragment extends Fragment implements Callback<CoffeeWrapper> {

    private String 		coffeeName, coffeeShop;
    private double 		coffeePrice, ratingValue;
    private EditText name, shop, price;
    private RatingBar ratingBar;
    private Button saveButton;
    private CoffeeMateApp app;
    public Call<CoffeeWrapper>  callCreate;

    public AddFragment() {
        // Required empty public constructor
    }

    public static AddFragment newInstance() {
        AddFragment fragment = new AddFragment();

        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        app = (CoffeeMateApp) getActivity().getApplication();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_add, container, false);
        getActivity().setTitle(R.string.addACoffeeLbl);
        name = v.findViewById(R.id.addNameET);
        shop =  v.findViewById(R.id.addShopET);
        price =  v.findViewById(R.id.addPriceET);
        ratingBar =  v.findViewById(R.id.addRatingBar);
        saveButton = v.findViewById(R.id.addCoffeeBtn);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addCoffee();
            }
        });

        return v;
    }

    public void addCoffee() {

        coffeeName = name.getText().toString();
        coffeeShop = shop.getText().toString();
        try {
            coffeePrice = Double.parseDouble(price.getText().toString());
        } catch (NumberFormatException e) {
            coffeePrice = 0.0;
        }
        ratingValue = ratingBar.getRating();

        if ((coffeeName.length() > 0) && (coffeeShop.length() > 0)
                && (price.length() > 0)) {
            Coffee c = new Coffee(coffeeName, coffeeShop, ratingValue,
                    coffeePrice, false);

            callCreate = app.coffeeService.post(c);
            callCreate.enqueue(this);
        } else
            Toast.makeText(
                    this.getActivity(),
                    "You must Enter Something for "
                            + "\'Name\', \'Shop\' and \'Price\'",
                    Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onResponse(Call<CoffeeWrapper> call, Response<CoffeeWrapper> response) {
        Toast.makeText(getActivity(),"Successfully Added Coffee" ,Toast.LENGTH_LONG).show();
        getActivity().startActivity(new Intent(getActivity(), Home.class));
      }

    @Override
    public void onFailure(Call<CoffeeWrapper> call, Throwable t) {
        Toast.makeText(getActivity(),"Unable to Add Coffee" ,Toast.LENGTH_LONG).show();
    }
}