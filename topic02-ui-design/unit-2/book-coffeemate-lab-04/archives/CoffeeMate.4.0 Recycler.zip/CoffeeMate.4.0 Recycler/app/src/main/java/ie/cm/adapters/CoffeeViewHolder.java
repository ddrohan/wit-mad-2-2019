package ie.cm.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DecimalFormat;

import ie.cm.R;
import ie.cm.models.Coffee;

public class CoffeeViewHolder extends RecyclerView.ViewHolder {
    public View view;
    public  Coffee coffee;
    public View.OnClickListener deleteListener;
    public View.OnClickListener clickListener;

    public CoffeeViewHolder(View v, View.OnClickListener delete,
                            View.OnClickListener click) {
        super(v);
        view = v;
        deleteListener = delete;
        clickListener = click;
    }

    public void updateControls(Coffee coffee) {

        view.setTag(coffee.coffeeId);
        view.setOnClickListener(clickListener);
        ImageView imgDelete = view.findViewById(R.id.rowDeleteImg);
        imgDelete.setTag(coffee);
        imgDelete.setOnClickListener(deleteListener);

        ((TextView) view.findViewById(R.id.rowCoffeeName)).setText(coffee.coffeeName);

        ((TextView) view.findViewById(R.id.rowCoffeeShop)).setText(coffee.shop);
        ((TextView) view.findViewById(R.id.rowRating)).setText(coffee.rating + " *");
        ((TextView) view.findViewById(R.id.rowPrice)).setText("€" +
                new DecimalFormat("0.00").format(coffee.price));

        ImageView imgIcon = view.findViewById(R.id.rowFavouriteImg);

        if (coffee.favourite == true)
            imgIcon.setImageResource(R.drawable.favourites_72_on);
        else
            imgIcon.setImageResource(R.drawable.favourites_72);
    }
}

