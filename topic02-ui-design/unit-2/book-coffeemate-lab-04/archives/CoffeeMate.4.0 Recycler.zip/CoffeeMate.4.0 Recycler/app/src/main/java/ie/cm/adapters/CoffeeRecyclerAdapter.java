package ie.cm.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import java.util.List;

import ie.cm.R;
import ie.cm.models.Coffee;

public class CoffeeRecyclerAdapter extends
                    RecyclerView.Adapter<CoffeeViewHolder>
{
    public Context context;
    public View.OnClickListener deleteListener, clickListener;
    public List<Coffee> coffeeList;
    public CoffeeViewHolder coffeeViewHolder;
    public View coffeeCardView;

    public CoffeeRecyclerAdapter(Context context,
                                 View.OnClickListener deleteListener,
                                 View.OnClickListener clickListener,
                                 List<Coffee> coffeeList)
    {
        this.context = context;
        this.clickListener = clickListener;
        this.deleteListener = deleteListener;
        this.coffeeList = coffeeList;
    }

    @NonNull
    @Override
    public CoffeeViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(viewGroup.getContext());
        coffeeCardView = inflater.inflate(R.layout.coffeecard, viewGroup, false);

        coffeeViewHolder = new CoffeeViewHolder(coffeeCardView, this.deleteListener,clickListener);
        return coffeeViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CoffeeViewHolder coffeeViewHolder, int i) {
        Coffee coffee = coffeeList.get(i);
        coffeeViewHolder.updateControls(coffee);
    }

    @Override
    public int getItemCount() {
        return coffeeList.size();
    }

    public void add(int position, Coffee item) {
        coffeeList.add(position, item);
        notifyItemInserted(position);
    }
    public void remove(int position) {
        coffeeList.remove(position);
        notifyItemRemoved(position);
    }
}
