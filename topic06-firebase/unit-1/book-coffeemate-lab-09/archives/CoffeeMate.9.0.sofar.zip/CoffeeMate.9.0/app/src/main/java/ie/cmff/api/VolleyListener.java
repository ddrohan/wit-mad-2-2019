package ie.cmff.api;

import android.support.v4.app.Fragment;
import java.util.List;
import ie.cmff.models.Coffee;

public interface VolleyListener {
    void setList(List list);
    void setCoffee(Coffee coffee);
    void updateUI(Fragment fragment);
}