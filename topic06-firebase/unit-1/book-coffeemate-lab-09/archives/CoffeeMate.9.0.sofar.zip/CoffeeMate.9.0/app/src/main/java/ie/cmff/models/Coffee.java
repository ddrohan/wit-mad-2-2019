package ie.cmff.models;

import java.io.Serializable;

public class Coffee implements Serializable
{
	public String _id;
	public String name;
	public String shop;
	public double rating;
	public double price;
	public boolean favourite;
	public String googlephoto;
	public String usertoken;
	public String address;
	public Marker marker = new Marker();


	public Coffee() {
		this.name = "";
		this.shop = "";
		this.rating = 0;
		this.price = 0.0;
		this.favourite = false;
		this.googlephoto = "";
		this.usertoken = "";
		this.address = "";
		this.marker.coords.latitude = 0.0;
		this.marker.coords.longitude = 0.0;
	}

	public Coffee(String name, String shop, double rating,
				  double price, boolean fav, String photo, String token,
				  String address,double lat, double lng)
	{
		//this._id = UUID.randomUUID().toString();
		this.name = name;
		this.shop = shop;
		this.rating = rating;
		this.price = price;
		this.favourite = fav;
		this.googlephoto = photo;
		this.usertoken = token;
		this.address = address;
		this.marker.coords.latitude = lat;
		this.marker.coords.longitude = lng;
	}

	@Override
	public String toString() {
		return "Coffee [name=" + name
				+ ", shop =" + shop + ", rating=" + rating + ", price=" + price
				+ ", fav =" + favourite + " "
				+ usertoken + " " + address + " " + marker.coords.latitude
				+ " " + marker.coords.longitude + "]";
	}
}
