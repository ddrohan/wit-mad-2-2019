package ie.cmff.adapters;

import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.firebase.ui.database.FirebaseListAdapter;
import com.firebase.ui.database.FirebaseListOptions;
import java.text.DecimalFormat;
import ie.cmff.R;
import ie.cmff.models.Coffee;


// https://github.com/firebase/FirebaseUI-Android/blob/master/README.md

// https://github.com/firebase/FirebaseUI-Android/blob/master/database/README.md

// https://groups.google.com/forum/#!topic/firebase-talk/O1kJ4VLUg10

public class CoffeeListAdapter extends FirebaseListAdapter<Coffee> {

    private View.OnClickListener deleteListener;
    FirebaseListOptions<Coffee> options;

    public CoffeeListAdapter(View.OnClickListener deleteListener,
                             FirebaseListOptions<Coffee> options) {
        super(options);
        this.deleteListener = deleteListener;
        this.options = options;
    }

    @Override
    protected void populateView(View row, Coffee coffee,int position) {
        //Set the rows TAG to the coffee 'key'
        row.setTag(getRef(position).getKey());

        ((TextView) row.findViewById(R.id.rowCoffeeName)).setText(coffee.name);
        ((TextView) row.findViewById(R.id.rowCoffeeShop)).setText(coffee.shop);
        ((TextView) row.findViewById(R.id.rowRating)).setText(coffee.rating + " *");
        ((TextView) row.findViewById(R.id.rowPrice)).setText("€" +
                new DecimalFormat("0.00").format(coffee.price));

        ImageView imgIcon = row.findViewById(R.id.rowFavouriteImg);

        if (coffee.favourite)
            imgIcon.setImageResource(R.drawable.favourites_72_on);
        else
            imgIcon.setImageResource(R.drawable.favourites_72);

        ImageView imgDelete = row.findViewById(R.id.rowDeleteImg);
        imgDelete.setTag(getRef(position).getKey());
        imgDelete.setOnClickListener(deleteListener);
    }
}