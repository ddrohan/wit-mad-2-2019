package ie.cmff.api;

import android.support.annotation.NonNull;
import android.util.Log;

import com.firebase.ui.database.FirebaseListOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import ie.cmff.R;
import ie.cmff.main.CoffeeMateApp;
import ie.cmff.models.Coffee;
import ie.cmff.models.User;

public class FirebaseManager {
    private static final String     TAG = "coffeemate";
    public          DatabaseReference   mFirebaseDatabase;
    public static   String              mFirebaseUserId;
    public FirebaseListener             mFirebaseListener;

    public void attachListener(FirebaseListener listener) {
        mFirebaseListener = listener;
    }

    public void open() {
        //Set up local caching
        FirebaseDatabase.getInstance().setPersistenceEnabled(true);

        //Bind to remote Firebase Database
        mFirebaseDatabase = FirebaseDatabase.getInstance().getReference();
        Log.v(TAG, "Database Connected :" + mFirebaseDatabase);
    }

    public void addCoffee(final Coffee c) {
        mFirebaseDatabase.child("users")
                .child(mFirebaseUserId).addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        // Get user value
                        User user = dataSnapshot.getValue(User.class);

                        if (user == null) {
                            // User is null, error out
                            Log.v(TAG, "User " + mFirebaseUserId + " is unexpectedly null");

                        } else {
                            // Write new coffee here
                            writeNewCoffee(c);
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Log.v(TAG, "getUser:onCancelled", databaseError.toException());
                    }
                });
    }

    private void writeNewCoffee(Coffee c) {
        // Create new coffee at /user-coffees/$userid/$coffeeid and at
        // /coffees/$coffeeid simultaneously
        String key = mFirebaseDatabase.child("coffees").push().getKey();
        Map<String, Object> coffeeValues = c.toMap();

        Map<String, Object> childUpdates = new HashMap<>();
        //All our coffees
        childUpdates.put("/coffees/" + key, coffeeValues);
        //All coffees per user
        childUpdates.put("/user-coffees/" + mFirebaseUserId + "/" + key, coffeeValues);

        mFirebaseDatabase.updateChildren(childUpdates).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                // Write was successful!
                Log.v(TAG, "updateChildren Write Successful");
            }
        })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Write failed
                        Log.v(TAG, "updateChildren Write Failed with Error : " + e.getLocalizedMessage());
                    }
                });
    }

    public Query getAllCoffees()
    {
        return mFirebaseDatabase
                .child("user-coffees")
                .child(mFirebaseUserId)
                .orderByChild("rating");
    }

    public Query getFavouriteCoffees()
    {
        return mFirebaseDatabase
                .child("user-coffees")
                .child(mFirebaseUserId)
                .orderByChild("favourite")
                .equalTo(true);
    }

    public void getACoffee(final String coffeeKey)
    {
        mFirebaseDatabase.child("user-coffees").child(mFirebaseUserId)
                .child(coffeeKey).addValueEventListener(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Log.v(TAG,"The read Succeeded: " + dataSnapshot.toString());
                        mFirebaseListener.onSuccess(dataSnapshot);
                    }
                    @Override
                    public void onCancelled(DatabaseError firebaseError) {
                        Log.v(TAG,"The read failed: " + firebaseError.getMessage());
                        mFirebaseListener.onFailure();
                    }
                });
    }

    public void updateACoffee(final String coffeeKey,final Coffee updatedCoffee)
    {
        mFirebaseDatabase.child("user-coffees").child(mFirebaseUserId)
                .child(coffeeKey).addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        Log.v(TAG,"The update Succeeded: " + dataSnapshot.toString());
                        dataSnapshot.getRef().setValue(updatedCoffee);
                    }
                    @Override
                    public void onCancelled(DatabaseError firebaseError) {
                        Log.v(TAG,"The update failed: " + firebaseError.getMessage());
                        mFirebaseListener.onFailure();
                    }
                });
    }

    public void toggleFavourite(final String coffeeKey,final boolean isFavourite)
    {
        mFirebaseDatabase.child("user-coffees").child(mFirebaseUserId).child(coffeeKey).addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        snapshot.getRef().child("favourite").setValue(isFavourite);
                    }
                    @Override
                    public void onCancelled(DatabaseError firebaseError) {
                        Log.v(TAG,"The toggle failed: " + firebaseError.getMessage());
                    }
                });
    }

    public void deleteACoffee(final String coffeeKey)
    {
        mFirebaseDatabase.child("user-coffees").child(mFirebaseUserId)
                .child(coffeeKey).addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot snapshot) {
                        snapshot.getRef().removeValue();
                    }
                    @Override
                    public void onCancelled(DatabaseError firebaseError) {
                        Log.v(TAG,"The delete failed: " + firebaseError.getMessage());
                    }
                });
    }

    public Query nameFilter(String s)
    {
        Query query = mFirebaseDatabase.child("user-coffees").child(mFirebaseUserId)
                .orderByChild("name").startAt(s).endAt(s+"\uf8ff");

        return query;
    }
}
