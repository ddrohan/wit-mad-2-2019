package ie.cmff.models;

public class Coords {
    public double latitude;
    public double longitude;
}
