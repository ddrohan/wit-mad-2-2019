package ie.cmff.api;

import com.google.firebase.database.DataSnapshot;

public interface FirebaseListener {
    void onSuccess(DataSnapshot dataSnapshot);
    void onFailure();
}
