package ie.cmff.main;

import ie.cmff.api.FirebaseManager;
import ie.cmff.models.Coffee;
import java.util.ArrayList;
import java.util.List;
import android.app.Application;
import android.graphics.Bitmap;
import android.location.Location;
import android.util.Log;

import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class CoffeeMateApp extends Application
{
    private static CoffeeMateApp mInstance;

    /* Client used to interact with Google APIs. */
    public GoogleApiClient mGoogleApiClient;
    public GoogleSignInOptions mGoogleSignInOptions;

    public boolean signedIn = false;
    public String googleToken;
    public String googleName;
    public String googleMail;
    public String googlePhotoURL;
    public Location mCurrentLocation;

    public FirebaseAuth mFirebaseAuth;
    public FirebaseUser mFirebaseUser;
    public FirebaseManager mFirebaseManager;

    public static final String TAG = CoffeeMateApp.class.getName();

    @Override
    public void onCreate() {
        super.onCreate();
        Log.v("coffeemate", "CoffeeMate App Started");
        mInstance = this;
        mFirebaseManager = new FirebaseManager();
        mFirebaseManager.open();
    }

    public static synchronized CoffeeMateApp getInstance() {
        return mInstance;
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
    }
}