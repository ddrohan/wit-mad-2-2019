package ie.cmff.models;

public class Marker {
    public int id = 1;
    public Coords coords = new Coords();
}
